<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Mon premier site Worpdress</title>   
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Un site utilisant WordPress">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<meta name='robots' content='noindex,follow' />
</head>
<body>
<div class="container">
    <div class="row">
	    <div class="col-12">    
        <img src="http://localhost/wordpress522/wp-content/uploads/2019/10/cropped-youpi_logo.png" alt="Mon premier site Worpdress" class="class-fluid">      </div>  <!-- .col -->  
	 </div>  <!-- .row -->   
	<div id="menu" role="navigation" class="border-top border-bottom m-3"> 
       <ul>
          <li class="page_item page-item-36"><a href="mentions-legales/">Mentions légales</a></li>
          <li class="page_item page-item-2"><a href="page-d-exemple/">Page d’exemple</a></li>
    </ul>
	</div>
    <div class="row">
	    <div class="col-8">
		    <h1><a href="http://localhost/wordpress522/2019/10/22/maecenas-luctus-justo/" title="Maecenas luctus justo">Maecenas luctus justo</a></h1>	
		    <p>Non dui accumsan, in maximus elit aliquet. Suspendisse a lectus pulvinar diam suscipit sagittis.</p>
        <div>
        </div>
		<hr>
		<h1><a href="http://localhost/wordpress522/2019/10/22/donec-maximus-pellentesque-nisi/" title="Donec maximus pellentesque nisi">Donec maximus pellentesque nisi</a></h1>	
		<p>A sodales erat ornare vel. Nulla sagittis ante magna, ac venenatis nunc aliquam ac. Nulla faucibus enim justo, eu pulvinar nunc sodales sed. In hac habitasse platea dictumst. Sed eget enim nibh. Vivamus et varius massa, non tincidunt ex. Maecenas quis urna vel urna congue. </p>
         <div></div><hr>				    <h1><a href="calhost/wordpress522/2019/10/22/lorem-ipsum/" title="Lorem ipsum">Lorem ipsum</a></h1>	
				    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nec ante  libero. Pellentesque vestibulum hendrerit turpis, sit amet tristique  nunc sagittis vitae. Cras eu faucibus ligula, ac porta nibh. Aliquam  erat volutpat. Aenean laoreet nunc turpis, id venenatis dolor rhoncus  vel.</p>
<div></div><hr>				    <h1><a href="http://localhost/wordpress522/2019/08/11/bonjour-tout-le-monde/" title="Bonjour tout le monde !">Bonjour tout le monde !</a></h1>	
				    <p>Bienvenue sur WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis commencez à écrire&nbsp;!</p>
<div></div><hr>	    
</div>
	    <!-- sidebar.php -->
<div class="col-4 border border-dark">
   [ SIDEBAR ]
</div>	 </div>
</div> <!-- .container -->  
<footer class="m-3">
	    <div class="row">
	        <div class="col-12 p-3 text-muted bg-dark text-center">
	        [ FOOTER ]
	        </div>
	    </div>
</div> <!-- .container -->  
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>