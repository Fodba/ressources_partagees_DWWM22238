<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
  <title>PHP Boucles : Exercice 2 corrigés</title>
    <style>
        table, tr, td, th
        { 
            border: 1px solid #000000; 
        } 
        </style>
</head>
<body>
<h1>PHP Boucles : Exercice 2 corrigés</h1>
<?php
/* Boucle 'for' (par exemple, peut fonctionner avec 'while' aussi) 
* jusqu'à 150 */
for ($i=0; $i<500; $i++)
{    
   echo "Je dois être acteur de ma formation<br>";
}
?>
</body>
</html>
